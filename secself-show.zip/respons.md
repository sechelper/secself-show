# 应急响应实战指南

[《应急响应实战指南》](http://security-incident-respons.secself.com)是助安社区历时一年打造的全真实案例写成的手册，这也是坤门内部🤞福利，不定期举行应急响应内部沙龙。

此系列文章对应**b站视频**观看效果更佳👍。

- 👉 [网络安全应急响应手册-Linux篇](https://www.bilibili.com/video/BV1FG4y1Y7UQ)
- 👉 [网络安全应急响应手册-Windows篇](https://space.bilibili.com/1233892570)
- [👉 网络安全应急响应手册-实战篇](https://space.bilibili.com/1233892570)
